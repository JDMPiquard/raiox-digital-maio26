// 4 variant themes — palette + type + ornaments
const VARIANTS = {
  v1: {
    id: "v1",
    name: "Cedofeita",
    tagline: "Refined cream · editorial calm",
    bg: "#f6f3ec",
    surface: "#fbf9f4",
    text: "#26241e",
    muted: "#73706a",
    rule: "#dcd5c6",
    accent: "#1f4d6b",     // ink-blue
    accentSoft: "#dbe5ec",
    accentInk: "#0e2b3d",
    ember: "#b46a3a",
    axisColors: ["#1f4d6b", "#2b2925", "#7a6e54"],
    fontDisplay: "'Fraunces', Georgia, serif",
    fontBody: "-apple-system, 'Segoe UI', system-ui, sans-serif",
    fontMono: "'JetBrains Mono', ui-monospace, monospace",
    radius: 14,
    waitingMode: "telex",
    chrome: "wordmark-line",
    dark: false,
  },
  v2: {
    id: "v2",
    name: "Broadsheet",
    tagline: "Newsprint editorial · ink + vermillion",
    bg: "#f1eadd",
    surface: "#f7f1e3",
    text: "#14110d",
    muted: "#5a5448",
    rule: "#1a1714",
    accent: "#b8341a",      // vermillion
    accentSoft: "#f0d8cf",
    accentInk: "#7a1f0c",
    ember: "#b8341a",
    axisColors: ["#14110d", "#b8341a", "#5a5448"],
    fontDisplay: "'Fraunces', Georgia, serif",
    fontBody: "-apple-system, 'Segoe UI', system-ui, sans-serif",
    fontMono: "'JetBrains Mono', ui-monospace, monospace",
    radius: 0,
    waitingMode: "broadsheet",
    chrome: "masthead",
    dark: false,
  },
  v3: {
    id: "v3",
    name: "Azulejo",
    tagline: "Porto tile · cobalt + terracotta",
    bg: "#f5eedf",
    surface: "#ffffff",
    text: "#0e1d33",
    muted: "#5d6577",
    rule: "#d8cdb5",
    accent: "#1d3f7a",      // cobalt
    accentSoft: "#d6e0f1",
    accentInk: "#0b224a",
    ember: "#c66339",       // terracotta
    axisColors: ["#1d3f7a", "#c66339", "#3a5c3a"],
    fontDisplay: "'DM Serif Display', Georgia, serif",
    fontBody: "-apple-system, 'Segoe UI', system-ui, sans-serif",
    fontMono: "'JetBrains Mono', ui-monospace, monospace",
    radius: 4,
    waitingMode: "tiles",
    chrome: "tile-corner",
    dark: false,
  },
  v4: {
    id: "v4",
    name: "Spotlight",
    tagline: "Cinematic ink · cream + ember",
    bg: "#14110d",
    surface: "#1c1813",
    text: "#f3e9d6",
    muted: "#9a8e76",
    rule: "#332c22",
    accent: "#e8b96a",       // ember gold
    accentSoft: "#3a2e1d",
    accentInk: "#f6dba3",
    ember: "#e8804a",
    axisColors: ["#e8b96a", "#e8804a", "#cfa97a"],
    fontDisplay: "'Instrument Serif', Georgia, serif",
    fontBody: "-apple-system, 'Segoe UI', system-ui, sans-serif",
    fontMono: "'JetBrains Mono', ui-monospace, monospace",
    radius: 4,
    waitingMode: "radar",
    chrome: "spotlight-bar",
    dark: true,
  },
};

// chrome — top brand bar per variant
function BrandChrome({ theme, sub }) {
  const t = theme;
  if (t.chrome === "masthead") {
    return (
      <div style={{ borderBottom: `2px solid ${t.text}`, padding: "8px 20px 6px", display: "flex", justifyContent: "space-between", alignItems: "baseline", fontFamily: t.fontMono, fontSize: 10, textTransform: "uppercase", letterSpacing: 1.2, color: t.text }}>
        <span style={{ fontWeight: 700 }}>AHI · O Diário do Comércio</span>
        <span>Nº 1 · 19 Maio 2026</span>
      </div>
    );
  }
  if (t.chrome === "tile-corner") {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 18px 6px" }}>
        <div style={{ width: 14, height: 14, background: t.accent, transform: "rotate(45deg)" }} />
        <span style={{ fontFamily: t.fontBody, fontSize: 12, fontWeight: 600, color: t.text, letterSpacing: 0.5 }}>AHI</span>
        <span style={{ fontFamily: t.fontBody, fontSize: 11, color: t.muted, letterSpacing: 0.5 }}>Fórum do Comércio</span>
      </div>
    );
  }
  if (t.chrome === "spotlight-bar") {
    return (
      <div style={{ padding: "8px 20px 4px", display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 1.4, textTransform: "uppercase" }}>
        <span>AHI · Fórum Comércio</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: t.ember, boxShadow: `0 0 8px ${t.ember}` }} /> LIVE
        </span>
      </div>
    );
  }
  // wordmark-line
  return (
    <div style={{ padding: "10px 20px 4px", display: "flex", alignItems: "baseline", gap: 8, fontFamily: t.fontBody, fontSize: 13, color: t.muted, letterSpacing: 0.2 }}>
      <span style={{ fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>AHI</span>
      <span style={{ width: 4, height: 4, borderRadius: 99, background: t.rule, alignSelf: "center" }} />
      <span>Fórum do Comércio do Porto</span>
    </div>
  );
}

// Tile motif (v3 only) — abstract azulejo block
function TileMotif({ theme, size = 64, kind = 0 }) {
  const t = theme;
  const c = t.accent;
  const e = t.ember;
  // kind 0..3 — different abstract tile patterns, NOT recreating any real azulejo
  const patterns = [
    // 0: quarter-circles
    <svg viewBox="0 0 64 64" width={size} height={size} key="0">
      <rect width="64" height="64" fill={t.surface} />
      <path d="M0 32 A32 32 0 0 1 32 0" stroke={c} strokeWidth="3" fill="none" />
      <path d="M32 64 A32 32 0 0 1 64 32" stroke={c} strokeWidth="3" fill="none" />
      <circle cx="32" cy="32" r="4" fill={e} />
    </svg>,
    // 1: diamond grid
    <svg viewBox="0 0 64 64" width={size} height={size} key="1">
      <rect width="64" height="64" fill={t.surface} />
      <path d="M32 6 L58 32 L32 58 L6 32 Z" stroke={c} strokeWidth="2" fill="none" />
      <path d="M32 18 L46 32 L32 46 L18 32 Z" fill={c} opacity="0.18" />
    </svg>,
    // 2: dotted cross
    <svg viewBox="0 0 64 64" width={size} height={size} key="2">
      <rect width="64" height="64" fill={t.surface} />
      <line x1="32" y1="6" x2="32" y2="58" stroke={c} strokeWidth="1.5" strokeDasharray="2 3" />
      <line x1="6" y1="32" x2="58" y2="32" stroke={c} strokeWidth="1.5" strokeDasharray="2 3" />
      <circle cx="32" cy="32" r="6" fill="none" stroke={e} strokeWidth="2" />
    </svg>,
    // 3: stripes
    <svg viewBox="0 0 64 64" width={size} height={size} key="3">
      <rect width="64" height="64" fill={t.surface} />
      {[0,1,2,3,4].map(i => <line key={i} x1={i*16} y1="0" x2={i*16-32} y2="64" stroke={c} strokeWidth="1.5" opacity={0.5} />)}
      <rect x="22" y="22" width="20" height="20" fill={e} opacity="0.85" />
    </svg>,
  ];
  return patterns[kind % patterns.length];
}

Object.assign(window, { VARIANTS, BrandChrome, TileMotif });
