// Phases 1, 2, 3 — search, confirm, waiting

const { useState, useEffect, useRef, useMemo } = React;

// ─────────────────────────────────────────────
// Phase 1 — SEARCH
// ─────────────────────────────────────────────
function Phase1Search({ theme, onSelect }) {
  const t = theme;
  const [q, setQ] = useState("");
  const [active, setActive] = useState(-1);
  const [focused, setFocused] = useState(false);

  const predictions = useMemo(() => {
    if (q.trim().length < 2) return [];
    const s = q.toLowerCase();
    return MOCK_PREDICTIONS.filter(p => p.name.toLowerCase().includes(s) || p.address.toLowerCase().includes(s)).slice(0, 8);
  }, [q]);

  const showList = focused && predictions.length > 0;

  function pick(p) {
    setQ(p.name);
    setActive(-1);
    setFocused(false);
    onSelect(p);
  }

  // variant-specific hero treatments
  const hero = (() => {
    if (t.id === "v2") {
      return (
        <div style={{ borderTop: `1px solid ${t.text}`, borderBottom: `4px double ${t.text}`, padding: "14px 20px 16px", marginBottom: 22 }}>
          <div style={{ fontFamily: t.fontMono, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: t.muted, marginBottom: 8 }}>Edição Especial</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 40, lineHeight: 0.95, color: t.text, fontWeight: 600, letterSpacing: -1 }}>
            O teu<br/><i style={{ color: t.accent }}>raio-x</i><br/>digital.
          </div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 19, color: t.text, marginTop: 12, fontStyle: "italic" }}>Em 90 segundos.</div>
        </div>
      );
    }
    if (t.id === "v3") {
      return (
        <div style={{ padding: "18px 20px 22px", position: "relative" }}>
          <div style={{ position: "absolute", top: 18, right: 14, opacity: 0.85 }}>
            <TileMotif theme={t} size={56} kind={0} />
          </div>
          <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.accent, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700, marginBottom: 12 }}>Raio-X Digital</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 38, lineHeight: 1.0, color: t.text, letterSpacing: -0.5 }}>Vê o teu raio-x<br/>em <span style={{ color: t.ember }}>90 segundos</span>.</div>
        </div>
      );
    }
    if (t.id === "v4") {
      return (
        <div style={{ padding: "20px 22px 26px" }}>
          <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Diagnóstico · 2026</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 46, lineHeight: 0.95, color: t.text, letterSpacing: -1 }}>
            Vê o teu<br/>
            <span style={{ fontStyle: "italic", color: t.accent }}>raio-x</span> digital<br/>
            <span style={{ color: t.muted, fontSize: 28, fontStyle: "italic" }}>em 90 segundos.</span>
          </div>
        </div>
      );
    }
    // v1
    return (
      <div style={{ padding: "18px 22px 22px" }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 36, lineHeight: 1.0, color: t.text, fontWeight: 400, letterSpacing: -0.6 }}>
          Vê o teu <i style={{ color: t.accent }}>raio-x</i><br/>digital em<br/>90 segundos.
        </div>
        <div style={{ width: 40, height: 2, background: t.accent, marginTop: 18 }} />
      </div>
    );
  })();

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44 }}>
      <BrandChrome theme={t} />
      {hero}

      <div style={{ padding: "0 20px", flex: 1 }}>
        <label style={{ display: "block", fontSize: 13, color: t.muted, marginBottom: 8, fontFamily: t.fontBody, fontWeight: 500, letterSpacing: 0.2 }}>
          A tua loja
        </label>
        <div style={{ position: "relative" }}>
          <input
            value={q}
            onChange={e => { setQ(e.target.value); setFocused(true); }}
            onFocus={() => setFocused(true)}
            onBlur={() => setTimeout(() => setFocused(false), 200)}
            placeholder="Começa a escrever…"
            style={{
              width: "100%", boxSizing: "border-box",
              padding: "14px 16px", fontSize: 18, fontFamily: t.fontBody,
              background: t.surface, color: t.text,
              border: `1px solid ${t.rule}`, borderRadius: t.radius,
              outline: "none",
            }}
          />
          {showList && (
            <div style={{ position: "absolute", top: "100%", left: 0, right: 0, marginTop: 6, background: t.surface, border: `1px solid ${t.rule}`, borderRadius: t.radius, overflow: "hidden", boxShadow: t.dark ? "0 8px 24px rgba(0,0,0,0.45)" : "0 8px 24px rgba(40,30,10,0.08)", zIndex: 5 }}>
              {predictions.map((p, i) => (
                <div key={p.place_id}
                  onMouseDown={() => pick(p)}
                  style={{ padding: "12px 16px", borderBottom: i < predictions.length-1 ? `1px solid ${t.rule}` : "none", cursor: "pointer", background: i === active ? t.accentSoft : "transparent" }}>
                  <div style={{ fontWeight: 600, fontSize: 16, color: t.text, marginBottom: 2 }}>{p.name}</div>
                  <div style={{ fontSize: 13, color: t.muted }}>{p.address}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <p style={{ fontSize: 13, color: t.muted, lineHeight: 1.5, marginTop: 24 }}>
          Lemos só fontes públicas (Google, Instagram, web).<br/>Não guardamos dados pessoais.
        </p>
      </div>

      {/* shop chips — quick demo entry */}
      <div style={{ padding: "0 20px 22px" }}>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 10 }}>Demo — toca para começar</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {MOCK_PREDICTIONS.slice(0, 3).map(p => (
            <button key={p.place_id} onClick={() => pick(p)}
              style={{ padding: "8px 12px", fontSize: 13, fontFamily: t.fontBody, background: "transparent", color: t.text, border: `1px solid ${t.rule}`, borderRadius: t.radius === 0 ? 0 : 999, cursor: "pointer" }}>
              {p.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// Phase 2 — CONFIRM
// ─────────────────────────────────────────────
function Phase2Confirm({ theme, shop, onConfirm, onBack }) {
  const t = theme;
  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44 }}>
      <BrandChrome theme={t} />

      <button onClick={onBack} style={{ alignSelf: "flex-start", margin: "10px 14px 0", background: "transparent", color: t.muted, border: "none", fontSize: 14, fontFamily: t.fontBody, cursor: "pointer", padding: "8px 10px" }}>
        ← voltar
      </button>

      <div style={{ flex: 1, padding: "20px 22px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 1.6, textTransform: "uppercase", marginBottom: 14 }}>
          A tua loja
        </div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 42, lineHeight: 1.0, color: t.text, letterSpacing: -0.6, marginBottom: 8 }}>
          {shop.name}
        </div>
        <div style={{ fontSize: 16, color: t.muted, marginBottom: 28 }}>
          {shop.address}
        </div>

        <div style={{ height: 1, background: t.rule, marginBottom: 28 }} />

        <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text, marginBottom: 24, fontStyle: t.id === "v2" || t.id === "v4" ? "italic" : "normal" }}>
          É esta a tua loja?
        </div>

        <button onClick={onConfirm} style={{
          padding: "16px 18px", fontSize: 17, fontFamily: t.fontBody, fontWeight: 600,
          background: t.accent, color: t.dark ? "#14110d" : "#fbf9f4", border: "none",
          borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer", marginBottom: 10,
          letterSpacing: 0.2,
        }}>
          Sim, começar →
        </button>
        <button onClick={onBack} style={{
          padding: "14px 18px", fontSize: 15, fontFamily: t.fontBody,
          background: "transparent", color: t.text, border: `1px solid ${t.rule}`,
          borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer",
        }}>
          Procurar outra
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// Phase 3 — WAITING (4 different metaphors)
// ─────────────────────────────────────────────
function Phase3Waiting({ theme, shop, onDone, paceMs = 1300 }) {
  const t = theme;
  const [events, setEvents] = useState([]);
  const [doneish, setDoneish] = useState(false);

  useEffect(() => {
    setEvents([]); setDoneish(false);
    const timers = [];
    MOCK_PROGRESS.forEach((p, i) => {
      timers.push(setTimeout(() => {
        setEvents(prev => [...prev, p]);
      }, i * paceMs + 200));
    });
    timers.push(setTimeout(() => setDoneish(true), MOCK_PROGRESS.length * paceMs + 800));
    timers.push(setTimeout(() => onDone(), MOCK_PROGRESS.length * paceMs + 1700));
    return () => timers.forEach(clearTimeout);
  }, [paceMs]);

  const lastStage = events.length ? events[events.length-1].stage : "identifying";
  const prog = doneish ? 1 : (STAGE_PROGRESS[lastStage] ?? 0.05);

  if (t.waitingMode === "broadsheet") return <WaitingBroadsheet theme={t} shop={shop} events={events} prog={prog} doneish={doneish} />;
  if (t.waitingMode === "tiles")      return <WaitingTiles      theme={t} shop={shop} events={events} prog={prog} doneish={doneish} />;
  if (t.waitingMode === "radar")      return <WaitingRadar      theme={t} shop={shop} events={events} prog={prog} doneish={doneish} />;
  return <WaitingTelex theme={t} shop={shop} events={events} prog={prog} doneish={doneish} />;
}

// ────── v1 Telex
function WaitingTelex({ theme: t, shop, events, prog, doneish }) {
  const facts = events.map(e => ({ ...factFromProgress(e), stage: e.stage, text: e.text })).filter(f => f && f.value != null);

  return (
    <div style={{ height: "100%", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44, display: "flex", flexDirection: "column" }}>
      <BrandChrome theme={t} />

      <div style={{ padding: "12px 22px 0" }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text }}>{shop.name}</div>
        <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.muted, letterSpacing: 1.3, textTransform: "uppercase", marginTop: 4 }}>
          {doneish ? "Análise concluída" : "A ler o que existe sobre ti…"}
        </div>
        {/* progress bar */}
        <div style={{ marginTop: 14, height: 3, background: t.rule, borderRadius: 99, overflow: "hidden" }}>
          <div style={{ width: `${prog*100}%`, height: "100%", background: t.accent, transition: "width 600ms ease" }} />
        </div>
      </div>

      {/* telex stream */}
      <div style={{ flex: 1, overflow: "hidden", padding: "18px 22px 12px", position: "relative" }}>
        <div style={{ position: "absolute", left: 22, top: 18, bottom: 12, width: 1, background: t.rule }} />
        <div style={{ paddingLeft: 18, display: "flex", flexDirection: "column", gap: 14 }}>
          {events.slice(-5).map((e, i) => {
            const f = factFromProgress(e);
            return (
              <TelexLine key={events.length - 5 + i} theme={t} event={e} fact={f} />
            );
          })}
        </div>
      </div>
    </div>
  );
}

function TelexLine({ theme: t, event, fact }) {
  const [shown, setShown] = useState(false);
  useEffect(() => { const id = requestAnimationFrame(() => setShown(true)); return () => cancelAnimationFrame(id); }, []);
  return (
    <div style={{ position: "relative", opacity: shown ? 1 : 0, transform: shown ? "translateY(0)" : "translateY(8px)", transition: "opacity 400ms, transform 400ms" }}>
      <div style={{ position: "absolute", left: -22, top: 6, width: 8, height: 8, background: t.accent, borderRadius: 99 }} />
      {fact && fact.value != null ? (
        <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: fact.isString ? 18 : 34, color: t.text, letterSpacing: -0.4, lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>
            {fact.isString ? fact.value : fmtPT(fact.value)}
          </div>
          <div style={{ fontSize: 13, color: t.muted }}>{fact.label}</div>
        </div>
      ) : (
        <div style={{ fontSize: 14, color: t.muted, fontFamily: t.fontMono }}>{event.text}</div>
      )}
    </div>
  );
}

// ────── v2 Broadsheet
function WaitingBroadsheet({ theme: t, shop, events, prog, doneish }) {
  return (
    <div style={{ height: "100%", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44, display: "flex", flexDirection: "column" }}>
      <BrandChrome theme={t} />
      <div style={{ padding: "14px 20px 8px", borderBottom: `1px solid ${t.text}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div style={{ fontFamily: t.fontMono, fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", color: t.muted }}>Reportagem em curso</div>
          <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted }}>{Math.round(prog*100)}%</div>
        </div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 28, lineHeight: 1.0, color: t.text, marginTop: 6, letterSpacing: -0.6 }}>
          {shop.name}
        </div>
      </div>

      <div style={{ flex: 1, overflow: "hidden", padding: "12px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
        {events.slice(-5).map((e, i) => {
          const f = factFromProgress(e);
          const ts = new Date(Date.now() + i*1000).toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
          return <BroadsheetEntry key={events.length-5+i} theme={t} event={e} fact={f} ts={ts} />;
        })}
        {doneish && (
          <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", color: t.accent, fontSize: 18, marginTop: 8 }}>
            — Edição fechada. A reportagem segue na página seguinte. —
          </div>
        )}
      </div>
    </div>
  );
}
function BroadsheetEntry({ theme: t, event, fact, ts }) {
  const [shown, setShown] = useState(false);
  useEffect(() => { const id = requestAnimationFrame(() => setShown(true)); return () => cancelAnimationFrame(id); }, []);
  return (
    <div style={{ opacity: shown ? 1 : 0, transform: shown ? "translateY(0)" : "translateY(6px)", transition: "opacity 400ms, transform 400ms", borderTop: `1px dotted ${t.rule}`, paddingTop: 10 }}>
      <div style={{ fontFamily: t.fontMono, fontSize: 9, color: t.muted, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 4 }}>
        {ts} · {event.stage?.replace("_", " ")}
      </div>
      {fact && fact.value != null ? (
        <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: fact.isString ? 17 : 32, color: t.text, lineHeight: 1, letterSpacing: -0.4, fontVariantNumeric: "tabular-nums" }}>
            {fact.isString ? fact.value : fmtPT(fact.value)}
          </div>
          <div style={{ fontSize: 14, color: t.text, fontFamily: t.fontDisplay, fontStyle: "italic" }}>{fact.label}</div>
        </div>
      ) : (
        <div style={{ fontSize: 15, color: t.text, fontFamily: t.fontDisplay, fontStyle: "italic" }}>{event.text}</div>
      )}
    </div>
  );
}

// ────── v3 Tiles
function WaitingTiles({ theme: t, shop, events, prog, doneish }) {
  const total = 9; // 3x3
  const lit = Math.min(total, events.length);
  const lastFact = (() => {
    for (let i = events.length - 1; i >= 0; i--) {
      const f = factFromProgress(events[i]);
      if (f) return f;
    }
    return null;
  })();
  return (
    <div style={{ height: "100%", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44, display: "flex", flexDirection: "column" }}>
      <BrandChrome theme={t} />
      <div style={{ padding: "12px 22px 4px" }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 26, color: t.text, letterSpacing: -0.4 }}>{shop.name}</div>
        <div style={{ fontFamily: t.fontBody, fontSize: 13, color: t.muted, marginTop: 4 }}>
          {doneish ? "Painel completo" : "A descobrir-te peça a peça…"}
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", padding: "0 22px" }}>
        {/* 3x3 tile grid — lights up as evidence arrives */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginBottom: 22 }}>
          {Array.from({ length: total }).map((_, i) => {
            const on = i < lit;
            return (
              <div key={i} style={{
                aspectRatio: "1 / 1",
                background: on ? t.surface : "transparent",
                border: `1px solid ${on ? t.accent : t.rule}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                opacity: on ? 1 : 0.35,
                transition: "opacity 500ms, background 500ms, border-color 500ms",
              }}>
                {on && <TileMotif theme={t} size={60} kind={i % 4} />}
              </div>
            );
          })}
        </div>
        {/* highlight */}
        {lastFact && (
          <div style={{ textAlign: "center" }}>
            <div style={{ fontFamily: t.fontDisplay, fontSize: lastFact.isString ? 22 : 56, color: t.accent, lineHeight: 1, letterSpacing: -1, fontVariantNumeric: "tabular-nums" }}>
              {lastFact.isString ? lastFact.value : fmtPT(lastFact.value)}
            </div>
            <div style={{ fontSize: 14, color: t.muted, marginTop: 6 }}>{lastFact.label}</div>
          </div>
        )}
      </div>

      <div style={{ padding: "0 22px 18px" }}>
        <div style={{ height: 2, background: t.rule, position: "relative", overflow: "hidden" }}>
          <div style={{ width: `${prog*100}%`, height: "100%", background: t.ember, transition: "width 600ms" }} />
        </div>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, textTransform: "uppercase", letterSpacing: 1.4, marginTop: 8 }}>
          {events.length ? events[events.length-1].text : "A começar…"}
        </div>
      </div>
    </div>
  );
}

// ────── v4 Radar
function WaitingRadar({ theme: t, shop, events, prog, doneish }) {
  const lastFact = (() => {
    for (let i = events.length - 1; i >= 0; i--) {
      const f = factFromProgress(events[i]);
      if (f) return f;
    }
    return null;
  })();
  const angle = events.length * 47; // sweep angle increments per event
  return (
    <div style={{ height: "100%", background: t.bg, color: t.text, fontFamily: t.fontBody, paddingTop: 44, display: "flex", flexDirection: "column", position: "relative", overflow: "hidden" }}>
      <BrandChrome theme={t} />
      <div style={{ padding: "10px 22px 0" }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 24, color: t.text, letterSpacing: -0.4 }}>{shop.name}</div>
      </div>

      {/* radar canvas */}
      <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
        {/* concentric rings */}
        <svg viewBox="-100 -100 200 200" style={{ position: "absolute", width: 360, height: 360 }}>
          {[30, 55, 80].map((r, i) => <circle key={i} r={r} cx="0" cy="0" fill="none" stroke={t.rule} strokeWidth="0.7" />)}
          {/* axis lines */}
          <line x1="-90" y1="0" x2="90" y2="0" stroke={t.rule} strokeWidth="0.5" strokeDasharray="2 3" />
          <line x1="0" y1="-90" x2="0" y2="90" stroke={t.rule} strokeWidth="0.5" strokeDasharray="2 3" />
          {/* sweep wedge */}
          <g style={{ transform: `rotate(${angle}deg)`, transition: "transform 1100ms cubic-bezier(0.6,0,0.3,1)", transformOrigin: "0 0" }}>
            <defs>
              <linearGradient id="sweep" x1="0" y1="0" x2="80" y2="0" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor={t.accent} stopOpacity="0.5"/>
                <stop offset="100%" stopColor={t.accent} stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d={`M0 0 L80 0 A80 80 0 0 0 75 -25 Z`} fill="url(#sweep)" />
            <line x1="0" y1="0" x2="82" y2="0" stroke={t.accent} strokeWidth="1.2" />
          </g>
          {/* event blips */}
          {events.map((e, i) => {
            const a = (i * 47) * Math.PI / 180;
            const r = 35 + ((i * 11) % 50);
            const x = Math.cos(a) * r, y = Math.sin(a) * r;
            return <circle key={i} cx={x} cy={y} r="2.4" fill={t.ember} />;
          })}
          <circle cx="0" cy="0" r="3" fill={t.text} />
        </svg>

        {/* center fact */}
        {lastFact && (
          <div style={{ position: "absolute", top: 22, right: 22, textAlign: "right", maxWidth: 200 }}>
            <div style={{ fontFamily: t.fontMono, fontSize: 9, color: t.muted, letterSpacing: 1.4, textTransform: "uppercase" }}>Captado</div>
            <div style={{ fontFamily: t.fontDisplay, fontSize: lastFact.isString ? 18 : 44, color: t.accent, lineHeight: 1, letterSpacing: -0.8, fontVariantNumeric: "tabular-nums", marginTop: 4 }}>
              {lastFact.isString ? lastFact.value : fmtPT(lastFact.value)}
            </div>
            <div style={{ fontSize: 12, color: t.muted, marginTop: 4 }}>{lastFact.label}</div>
          </div>
        )}
      </div>

      <div style={{ padding: "0 22px 16px" }}>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, textTransform: "uppercase", letterSpacing: 1.4, marginBottom: 6 }}>
          {events.length ? events[events.length-1].text : "A iniciar varredura…"}
        </div>
        <div style={{ height: 2, background: t.rule }}>
          <div style={{ width: `${prog*100}%`, height: "100%", background: t.accent, transition: "width 700ms" }} />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Phase1Search, Phase2Confirm, Phase3Waiting });
