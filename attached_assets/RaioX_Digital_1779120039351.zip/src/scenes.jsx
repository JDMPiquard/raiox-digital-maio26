// Phase 4 reveal scenes + Phase 5 share landing

const { useState: useS, useEffect: useE, useRef: useR } = React;

// count-up hook
function useCountUp(target, { duration = 1200, run = true } = {}) {
  const [val, setVal] = useS(typeof target === "number" ? 0 : target);
  useE(() => {
    if (!run) return;
    if (typeof target !== "number") { setVal(target); return; }
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) { setVal(target); return; }
    let raf;
    const start = performance.now();
    function step(now) {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(Math.floor(target * eased));
      if (t < 1) raf = requestAnimationFrame(step);
      else setVal(target);
    }
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, run]);
  return val;
}

// progress dots
function Dots({ count, current, theme }) {
  const t = theme;
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "center", justifyContent: "center" }}>
      {Array.from({ length: count }).map((_, i) => {
        const active = i === current;
        const done = i < current;
        return (
          <div key={i} style={{
            width: active ? 18 : 6, height: 4, borderRadius: 99,
            background: done ? t.accent : (active ? t.accent : t.rule),
            transition: "width 260ms, background 260ms",
          }} />
        );
      })}
    </div>
  );
}

// reveal wrapper — owns scene index + auto-advance + tap target
function Reveal({ theme, result, isSharedView = false, onRestart }) {
  const t = theme;
  const hasLab = !!result.lab_hint;
  // scenes: hero, discovery, vis, rep, con, esta, lab?, share  -- in shared view, lab → "faz o teu"
  const sceneIds = ["hero","discovery","vis","rep","con","esta"];
  if (hasLab || isSharedView) sceneIds.push("lab");
  sceneIds.push("share");

  const [idx, setIdx] = useS(0);
  const total = sceneIds.length;

  const dwellMs = (id) => {
    if (id === "hero") return 4200;
    if (id === "discovery") return 5500;
    if (id === "esta") return 7000;
    if (id === "lab") return 6500;
    if (id === "share") return 99999; // no auto-advance
    return 7500; // axes
  };

  useE(() => {
    if (idx >= sceneIds.length - 1) return;
    const id = sceneIds[idx];
    const ms = dwellMs(id);
    const tm = setTimeout(() => setIdx(i => Math.min(sceneIds.length - 1, i + 1)), ms);
    return () => clearTimeout(tm);
  }, [idx]);

  function advance() {
    setIdx(i => Math.min(sceneIds.length - 1, i + 1));
  }

  const sources = ["Google", "Instagram", "Facebook", "Site", "Comércio com História", "Time Out"];

  function renderScene(id) {
    switch (id) {
      case "hero": return <SceneHero theme={t} result={result} />;
      case "discovery": return <SceneDiscovery theme={t} count={6} sources={sources} />;
      case "vis": return <SceneAxis theme={t} axis={result.axes[0]} idx={0} />;
      case "rep": return <SceneAxis theme={t} axis={result.axes[1]} idx={1} />;
      case "con": return <SceneAxis theme={t} axis={result.axes[2]} idx={2} />;
      case "esta": return <SceneEstaSemana theme={t} result={result} />;
      case "lab":
        if (isSharedView) return <SceneSharedCTA theme={t} />;
        return <SceneLab theme={t} labHint={result.lab_hint} />;
      case "share": return <SceneShare theme={t} result={result} onRestart={onRestart} />;
      default: return null;
    }
  }

  const currentId = sceneIds[idx];
  const isShareScene = currentId === "share";

  return (
    <div style={{ position: "relative", height: "100%", background: t.bg, color: t.text, fontFamily: t.fontBody, overflow: "hidden" }}>
      {/* status bar pad */}
      <div style={{ height: 44 }} />

      {/* progress dots */}
      <div style={{ padding: "4px 22px 0", display: "flex", alignItems: "center", gap: 12 }}>
        <Dots count={total} current={idx} theme={t} />
        <div style={{ flex: 1 }} />
        {!isShareScene && (
          <button onClick={advance} style={{ background: "transparent", border: "none", color: t.muted, fontFamily: t.fontMono, fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", cursor: "pointer", padding: 4 }}>
            saltar →
          </button>
        )}
      </div>

      {/* tap target — whole viewport advances except over buttons */}
      <div onClick={advance} style={{ position: "absolute", inset: 0, top: 80, bottom: 60, cursor: "pointer" }} />

      {/* scene */}
      <div key={idx} style={{ position: "absolute", top: 80, left: 0, right: 0, bottom: 60, pointerEvents: "none" }}>
        <div style={{ width: "100%", height: "100%", animation: "scenein 420ms ease both", pointerEvents: "none" }}>
          <div style={{ width: "100%", height: "100%", pointerEvents: "auto" }}>
            {renderScene(currentId)}
          </div>
        </div>
      </div>

      {/* footer — recomeçar */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 18, textAlign: "center", pointerEvents: "none" }}>
        <button onClick={onRestart} style={{ pointerEvents: "auto", background: "transparent", border: "none", color: t.muted, fontSize: 11, fontFamily: t.fontBody, cursor: "pointer", textDecoration: "underline", textDecorationColor: t.rule }}>
          Esta análise não bate certo? Recomeça aqui.
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 1 — HERO
// ─────────────────────────────────────────────
function SceneHero({ theme: t, result }) {
  const shop = result.shop;
  if (t.id === "v2") {
    return (
      <div style={{ height: "100%", padding: "8px 20px 20px", display: "flex", flexDirection: "column" }}>
        <div style={{ borderTop: `4px double ${t.text}`, borderBottom: `1px solid ${t.text}`, padding: "8px 0", display: "flex", justifyContent: "space-between", fontFamily: t.fontMono, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: t.text }}>
          <span>Edição Nº 1</span><span>Pág. A1</span>
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.muted, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>O Raio-X Digital de</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 56, lineHeight: 0.92, color: t.text, fontWeight: 700, letterSpacing: -1.5 }}>
            {shop.name.split(" ").map((w, i) => (
              <div key={i} style={{ color: i === 0 ? t.accent : t.text, fontStyle: i === 0 ? "italic" : "normal" }}>{w}</div>
            ))}
          </div>
          <div style={{ height: 1, background: t.text, marginTop: 22, marginBottom: 14, width: 80 }} />
          <div style={{ fontFamily: t.fontDisplay, fontSize: 16, color: t.text, fontStyle: "italic" }}>uma reportagem de 90 segundos<br/>sobre o que a internet diz de ti.</div>
        </div>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 2, textTransform: "uppercase", textAlign: "right" }}>— AHI —</div>
      </div>
    );
  }
  if (t.id === "v3") {
    return (
      <div style={{ height: "100%", padding: "12px 22px 20px", display: "flex", flexDirection: "column", position: "relative" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginBottom: 22 }}>
          {[0,1,2,3,2,1].map((k, i) => (
            <div key={i} style={{ aspectRatio: "1/1", border: `1px solid ${t.accent}` }}>
              <TileMotif theme={t} size={80} kind={k} />
            </div>
          ))}
        </div>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.accent, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700, marginBottom: 14 }}>O raio-x digital de</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 46, lineHeight: 0.95, color: t.text, letterSpacing: -0.8 }}>{shop.name}</div>
          <div style={{ fontSize: 14, color: t.muted, marginTop: 12 }}>{shop.address}</div>
        </div>
        <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.ember, letterSpacing: 2, textTransform: "uppercase", textAlign: "right", fontWeight: 600 }}>· AHI ·</div>
      </div>
    );
  }
  if (t.id === "v4") {
    return (
      <div style={{ height: "100%", padding: "12px 22px 20px", display: "flex", flexDirection: "column", justifyContent: "center", position: "relative" }}>
        <div style={{ position: "absolute", top: 0, left: 22, right: 22, fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 2.4, textTransform: "uppercase" }}>O Raio-X Digital de</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 64, lineHeight: 0.9, color: t.text, letterSpacing: -2, fontStyle: "italic" }}>
          {shop.name}
        </div>
        <div style={{ width: 60, height: 2, background: t.ember, marginTop: 22, boxShadow: `0 0 12px ${t.ember}` }} />
        <div style={{ fontFamily: t.fontBody, fontSize: 14, color: t.muted, marginTop: 16, maxWidth: 280 }}>
          o que a internet diz sobre ti — em oito momentos.
        </div>
        <div style={{ position: "absolute", bottom: 0, right: 22, fontFamily: t.fontMono, fontSize: 11, color: t.ember, letterSpacing: 2, textTransform: "uppercase" }}>AHI</div>
      </div>
    );
  }
  // v1
  return (
    <div style={{ height: "100%", padding: "20px 24px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
      <div style={{ fontFamily: t.fontBody, fontSize: 12, color: t.muted, letterSpacing: 1.6, textTransform: "uppercase", marginBottom: 16, fontWeight: 600 }}>O Raio-X Digital de</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: 52, lineHeight: 0.95, color: t.text, letterSpacing: -1.2, fontWeight: 400 }}>
        {shop.name}
      </div>
      <div style={{ width: 50, height: 2, background: t.accent, marginTop: 24, marginBottom: 16 }} />
      <div style={{ fontSize: 15, color: t.muted, lineHeight: 1.5, maxWidth: 280 }}>
        Uma leitura editorial<br/>do que existe sobre ti.
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ fontFamily: t.fontBody, fontSize: 12, color: t.muted, letterSpacing: 1.4, textTransform: "uppercase", fontWeight: 600 }}>— AHI</div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 2 — DISCOVERY (Encontrei-te em N)
// ─────────────────────────────────────────────
function SceneDiscovery({ theme: t, count, sources }) {
  const n = useCountUp(count, { duration: 1100 });
  const [revealed, setRevealed] = useS(0);
  useE(() => {
    let i = 0;
    const id = setInterval(() => { i++; setRevealed(r => Math.min(sources.length, r + 1)); if (i >= sources.length) clearInterval(id); }, 280);
    return () => clearInterval(id);
  }, []);

  if (t.id === "v2") {
    return (
      <div style={{ height: "100%", padding: "10px 20px 20px" }}>
        <div style={{ borderTop: `1px solid ${t.text}`, borderBottom: `1px solid ${t.text}`, padding: "8px 0", fontFamily: t.fontMono, fontSize: 10, letterSpacing: 1.6, textTransform: "uppercase", color: t.muted }}>Capítulo I — Onde estás</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 24, color: t.text, marginTop: 14, fontStyle: "italic" }}>Encontrei-te em</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 130, lineHeight: 0.9, color: t.accent, fontVariantNumeric: "tabular-nums", letterSpacing: -4, fontWeight: 700 }}>{n}</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 20, color: t.text, fontStyle: "italic", marginTop: 4 }}>sítios na internet.</div>
        <div style={{ marginTop: 22, columns: 2, columnGap: 12, columnRule: `1px solid ${t.rule}` }}>
          {sources.slice(0, revealed).map((s, i) => (
            <div key={i} style={{ breakInside: "avoid", fontFamily: t.fontDisplay, fontSize: 15, color: t.text, padding: "4px 0", borderBottom: `1px dotted ${t.rule}` }}>
              <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, marginRight: 6 }}>{String(i+1).padStart(2, "0")}</span>{s}
            </div>
          ))}
        </div>
      </div>
    );
  }
  if (t.id === "v3") {
    return (
      <div style={{ height: "100%", padding: "16px 22px 20px", display: "flex", flexDirection: "column" }}>
        <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.accent, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700, marginBottom: 6 }}>Capítulo I</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text, letterSpacing: -0.4, marginBottom: 4 }}>Encontrei-te em</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 16 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 110, lineHeight: 0.9, color: t.accent, fontVariantNumeric: "tabular-nums", letterSpacing: -3 }}>{n}</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text }}>canais.</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginTop: 18 }}>
          {sources.slice(0, revealed).map((s, i) => (
            <div key={i} style={{ aspectRatio: "1/1", border: `1px solid ${t.accent}`, background: t.surface, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 6 }}>
              <div style={{ flex: 1, display: "flex", alignItems: "center" }}><TileMotif theme={t} size={36} kind={i % 4} /></div>
              <div style={{ fontFamily: t.fontBody, fontSize: 10, color: t.text, textAlign: "center", letterSpacing: 0.2, fontWeight: 600 }}>{s}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  if (t.id === "v4") {
    return (
      <div style={{ height: "100%", padding: "16px 24px 20px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.muted, letterSpacing: 2, textTransform: "uppercase" }}>Capítulo I · Onde estás</div>
        <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 26, color: t.text, marginTop: 12 }}>Encontrei-te em</div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 170, lineHeight: 0.85, color: t.accent, fontVariantNumeric: "tabular-nums", letterSpacing: -8, textShadow: `0 0 30px ${t.accent}40` }}>{n}</div>
        </div>
        <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 22, color: t.muted, marginTop: -8 }}>sítios diferentes.</div>
        <div style={{ marginTop: 22, display: "flex", flexDirection: "column", gap: 4 }}>
          {sources.slice(0, revealed).map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "baseline", gap: 12, borderBottom: `1px solid ${t.rule}`, paddingBottom: 4 }}>
              <span style={{ fontFamily: t.fontMono, fontSize: 11, color: t.ember }}>{String(i+1).padStart(2, "0")}</span>
              <span style={{ fontFamily: t.fontDisplay, fontSize: 18, color: t.text }}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }
  // v1
  return (
    <div style={{ height: "100%", padding: "16px 24px 20px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
      <div style={{ fontFamily: t.fontBody, fontSize: 12, color: t.muted, letterSpacing: 1.6, textTransform: "uppercase", fontWeight: 600 }}>Capítulo I</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text, marginTop: 10 }}>Encontrei-te em</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 130, lineHeight: 0.9, color: t.accent, fontVariantNumeric: "tabular-nums", letterSpacing: -4 }}>{n}</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 22, color: t.text }}>sítios.</div>
      </div>
      <div style={{ height: 1, background: t.rule, margin: "18px 0" }} />
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {sources.slice(0, revealed).map((s, i) => (
          <span key={i} style={{ padding: "6px 10px", border: `1px solid ${t.rule}`, borderRadius: 99, fontSize: 13, color: t.text, background: t.surface }}>{s}</span>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 3-5 — AXIS
// ─────────────────────────────────────────────
function SceneAxis({ theme: t, axis, idx }) {
  const accent = t.axisColors[idx] || t.accent;
  const bn = axis.bigNumber || {};
  const num = useCountUp(typeof bn.value === "number" ? bn.value : bn.value, { duration: 1100 });
  const numStr = typeof bn.value === "number" ? fmtPT(num) : bn.value;

  if (t.id === "v2") {
    return (
      <div style={{ height: "100%", padding: "10px 20px 20px" }}>
        <div style={{ borderTop: `1px solid ${t.text}`, borderBottom: `1px solid ${t.text}`, padding: "8px 0", display: "flex", justifyContent: "space-between", fontFamily: t.fontMono, fontSize: 10, letterSpacing: 1.6, textTransform: "uppercase", color: t.muted }}>
          <span>Capítulo {["II — Visibilidade","III — Reputação","IV — Consistência"][idx]}</span><span>Pág. A{idx+2}</span>
        </div>
        <div style={{ display: "flex", alignItems: "baseline", gap: 16, marginTop: 16 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 60, color: accent, lineHeight: 0.9, fontVariantNumeric: "tabular-nums", letterSpacing: -2, fontWeight: 700 }}>{numStr}</div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 15, color: t.text, fontStyle: "italic", maxWidth: 130 }}>{bn.label}{bn.suffix ? ` · ${bn.suffix}` : ""}</div>
        </div>
        <div style={{ marginTop: 16, columnRule: `1px solid ${t.rule}` }}>
          <p style={{ fontFamily: t.fontDisplay, fontSize: 15, lineHeight: 1.4, color: t.text, margin: 0 }}>
            <span style={{ float: "left", fontSize: 48, lineHeight: 0.85, paddingRight: 8, paddingTop: 4, color: accent, fontWeight: 700 }}>{axis.summary.charAt(0)}</span>
            {axis.summary.slice(1)}
          </p>
        </div>
        <div style={{ marginTop: 16, fontFamily: t.fontMono, fontSize: 9, letterSpacing: 1.8, textTransform: "uppercase", color: accent }}>Esta semana podes</div>
        <ol style={{ margin: "6px 0 0", padding: 0, listStyle: "none" }}>
          {axis.recommendations.slice(0, 2).map((r, i) => (
            <li key={i} style={{ display: "flex", gap: 10, fontFamily: t.fontDisplay, fontSize: 14, color: t.text, padding: "6px 0", borderBottom: `1px dotted ${t.rule}`, fontStyle: "italic" }}>
              <span style={{ fontFamily: t.fontMono, fontSize: 11, color: accent, fontStyle: "normal" }}>{String(i+1).padStart(2,"0")}</span>
              <span>{r.action}</span>
            </li>
          ))}
        </ol>
      </div>
    );
  }
  if (t.id === "v3") {
    return (
      <div style={{ height: "100%", padding: "12px 22px 18px", display: "flex", flexDirection: "column", position: "relative" }}>
        <div style={{ position: "absolute", top: 16, right: 18, opacity: 0.4 }}>
          <TileMotif theme={t} size={64} kind={idx} />
        </div>
        <div style={{ fontFamily: t.fontBody, fontSize: 11, color: accent, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700 }}>Eixo {idx+1} de 3</div>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 38, color: t.text, letterSpacing: -0.8, marginTop: 6 }}>{axis.name}</div>
        <div style={{ border: `1px solid ${accent}`, background: t.surface, padding: "14px 16px", marginTop: 14 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 44, color: accent, lineHeight: 0.95, fontVariantNumeric: "tabular-nums", letterSpacing: -1 }}>{numStr}</div>
          <div style={{ fontSize: 13, color: t.muted, marginTop: 2 }}>{bn.label}{bn.suffix ? ` · ${bn.suffix}` : ""}</div>
        </div>
        <p style={{ fontSize: 14, lineHeight: 1.55, color: t.text, marginTop: 14, marginBottom: 12 }}>{axis.summary}</p>
        <div style={{ fontFamily: t.fontBody, fontSize: 10, color: t.ember, letterSpacing: 1.8, textTransform: "uppercase", fontWeight: 700, marginTop: 4 }}>Esta semana podes</div>
        {axis.recommendations.slice(0, 2).map((r, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginTop: 6, alignItems: "flex-start" }}>
            <div style={{ width: 10, height: 10, background: t.ember, transform: "rotate(45deg)", marginTop: 5, flexShrink: 0 }} />
            <div style={{ fontSize: 13, lineHeight: 1.45, color: t.text }}>{r.action}</div>
          </div>
        ))}
      </div>
    );
  }
  if (t.id === "v4") {
    return (
      <div style={{ height: "100%", padding: "10px 22px 20px", display: "flex", flexDirection: "column" }}>
        <div style={{ fontFamily: t.fontMono, fontSize: 11, color: t.muted, letterSpacing: 2, textTransform: "uppercase" }}>Eixo {idx+1} · {["Visibilidade","Reputação","Consistência"][idx]}</div>
        <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 44, color: t.text, marginTop: 8, letterSpacing: -1, lineHeight: 1 }}>{axis.name}</div>
        <div style={{ width: 40, height: 2, background: accent, marginTop: 14, boxShadow: `0 0 12px ${accent}` }} />
        <div style={{ display: "flex", alignItems: "baseline", gap: 14, marginTop: 18 }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 88, color: accent, lineHeight: 0.85, fontVariantNumeric: "tabular-nums", letterSpacing: -2.5 }}>{numStr}</div>
          <div style={{ fontSize: 13, color: t.muted, maxWidth: 110 }}>{bn.label}{bn.suffix ? `\n${bn.suffix}` : ""}</div>
        </div>
        <p style={{ fontSize: 14, lineHeight: 1.55, color: t.text, marginTop: 14, marginBottom: 10 }}>{axis.summary}</p>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.ember, letterSpacing: 2, textTransform: "uppercase", marginTop: 4 }}>Esta semana podes</div>
        {axis.recommendations.slice(0, 2).map((r, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginTop: 6 }}>
            <span style={{ fontFamily: t.fontMono, fontSize: 11, color: t.ember }}>→</span>
            <span style={{ fontSize: 13, lineHeight: 1.45, color: t.text }}>{r.action}</span>
          </div>
        ))}
      </div>
    );
  }
  // v1
  return (
    <div style={{ height: "100%", padding: "12px 24px 18px", display: "flex", flexDirection: "column" }}>
      <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.muted, letterSpacing: 1.8, textTransform: "uppercase", fontWeight: 600 }}>Eixo {idx+1} de 3</div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 6 }}>
        <div style={{ width: 28, height: 2, background: accent }} />
        <div style={{ fontFamily: t.fontDisplay, fontSize: 32, color: t.text, letterSpacing: -0.6 }}>{axis.name}</div>
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 14, marginTop: 22 }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 72, color: accent, lineHeight: 0.85, fontVariantNumeric: "tabular-nums", letterSpacing: -2 }}>{numStr}</div>
        <div style={{ fontSize: 13, color: t.muted, maxWidth: 120 }}>{bn.label}{bn.suffix ? ` · ${bn.suffix}` : ""}</div>
      </div>
      <p style={{ fontSize: 15, lineHeight: 1.5, color: t.text, marginTop: 18, marginBottom: 14 }}>{axis.summary}</p>
      <div style={{ fontFamily: t.fontBody, fontSize: 11, color: accent, letterSpacing: 1.8, textTransform: "uppercase", fontWeight: 700 }}>Esta semana podes</div>
      {axis.recommendations.slice(0, 2).map((r, i) => (
        <div key={i} style={{ display: "flex", gap: 10, marginTop: 8, alignItems: "flex-start" }}>
          <span style={{ color: accent, fontFamily: t.fontDisplay, fontSize: 18, lineHeight: 1 }}>→</span>
          <span style={{ fontSize: 13.5, lineHeight: 1.5, color: t.text }}>{r.action}</span>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 6 — ESTA SEMANA
// ─────────────────────────────────────────────
function SceneEstaSemana({ theme: t, result }) {
  const recs = result.axes.map((a, i) => ({ axis: a.name, action: a.recommendations[0].action, color: t.axisColors[i] }));

  const titleNode = (() => {
    if (t.id === "v2") return <div style={{ fontFamily: t.fontDisplay, fontSize: 32, color: t.text, letterSpacing: -0.6, fontWeight: 700 }}>Agenda<br/><i style={{ color: t.accent }}>desta semana.</i></div>;
    if (t.id === "v3") return <div style={{ fontFamily: t.fontDisplay, fontSize: 36, color: t.text, letterSpacing: -0.5, lineHeight: 1 }}>O que fazer<br/>esta semana.</div>;
    if (t.id === "v4") return <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 44, color: t.text, letterSpacing: -1, lineHeight: 1 }}>O que fazer<br/>esta semana.</div>;
    return <div style={{ fontFamily: t.fontDisplay, fontSize: 34, color: t.text, letterSpacing: -0.6, lineHeight: 1 }}>O que fazer<br/>esta semana.</div>;
  })();

  return (
    <div style={{ height: "100%", padding: "10px 24px 20px", display: "flex", flexDirection: "column" }}>
      {t.id === "v2" && <div style={{ borderTop: `1px solid ${t.text}`, borderBottom: `4px double ${t.text}`, padding: "8px 0", marginBottom: 14, fontFamily: t.fontMono, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: t.text }}>Capítulo V — Agenda</div>}
      {titleNode}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 14, marginTop: 24 }}>
        {recs.map((r, i) => (
          <div key={i} style={{ display: "flex", gap: 14, paddingBottom: 12, borderBottom: i < 2 ? `1px solid ${t.rule}` : "none" }}>
            <div style={{ fontFamily: t.fontDisplay, fontSize: 44, color: r.color, lineHeight: 0.9, fontWeight: t.id === "v2" ? 700 : 400, letterSpacing: -1, fontStyle: t.id === "v4" ? "italic" : "normal", flexShrink: 0, width: 42 }}>
              {i + 1}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: t.fontMono, fontSize: 9, color: r.color, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 4 }}>{r.axis}</div>
              <div style={{ fontSize: 13.5, lineHeight: 1.5, color: t.text }}>{r.action}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 14, color: t.muted, textAlign: "right" }}>
        Cada um leva menos de 30 minutos.
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 7 — LAB CTA
// ─────────────────────────────────────────────
function SceneLab({ theme: t, labHint }) {
  const lab = LAB_MAP[labHint];
  if (!lab) return null;
  const labelStyle = { fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 2, textTransform: "uppercase" };

  return (
    <div style={{ height: "100%", padding: "10px 24px 20px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
      <div style={labelStyle}>Amanhã · 14:00 · Alfândega</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: t.id === "v4" ? 28 : 22, color: t.muted, fontStyle: "italic", marginTop: 14 }}>{`Lab ${lab.num}`}</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: 38, color: t.text, lineHeight: 1.0, letterSpacing: -0.8, marginTop: 4 }}>
        {lab.title}
      </div>
      <div style={{ width: 50, height: 2, background: t.accent, marginTop: 18 }} />
      <div style={{ fontSize: 13, color: t.muted, marginTop: 14, lineHeight: 1.5 }}>
        Salão Nobre, Alfândega do Porto.<br/>
        Vais aprender a montar o teu primeiro planeador de campanhas. Sem código.
      </div>
      <button style={{
        marginTop: 24, padding: "14px 18px", fontSize: 16, fontFamily: t.fontBody, fontWeight: 600,
        background: t.accent, color: t.dark ? "#14110d" : "#fbf9f4", border: "none",
        borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer", alignSelf: "flex-start",
        minWidth: 200,
      }} onClick={e => e.stopPropagation()}>
        Lembra-me →
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 7 (shared view) — "Faz o teu raio-x"
// ─────────────────────────────────────────────
function SceneSharedCTA({ theme: t }) {
  return (
    <div style={{ height: "100%", padding: "10px 24px 20px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
      <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 2, textTransform: "uppercase" }}>Tens uma loja?</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: 42, color: t.text, lineHeight: 1.0, letterSpacing: -0.8, marginTop: 12 }}>
        Faz o <i style={{ color: t.accent }}>teu</i> raio-x.
      </div>
      <div style={{ fontSize: 14, color: t.muted, marginTop: 14, lineHeight: 1.5, maxWidth: 280 }}>
        90 segundos. Não pedimos email, nem telefone, nem nada.
      </div>
      <button style={{
        marginTop: 24, padding: "14px 18px", fontSize: 16, fontFamily: t.fontBody, fontWeight: 600,
        background: t.accent, color: t.dark ? "#14110d" : "#fbf9f4", border: "none",
        borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer", alignSelf: "flex-start",
      }} onClick={e => e.stopPropagation()}>
        raiox.j24d.com →
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────
// SCENE 8 — SHARE
// ─────────────────────────────────────────────
function SceneShare({ theme: t, result, onRestart }) {
  const [copied, setCopied] = useS(false);
  const shareUrl = `https://raiox.j24d.com/r/${result.shop.place_id || "demo"}`;
  function copy() {
    if (navigator.clipboard) navigator.clipboard.writeText(shareUrl).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div style={{ height: "100%", padding: "10px 24px 20px", display: "flex", flexDirection: "column" }}>
      {t.id === "v2" && <div style={{ borderTop: `4px double ${t.text}`, borderBottom: `1px solid ${t.text}`, padding: "8px 0", fontFamily: t.fontMono, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: t.text }}>Última página · Partilha</div>}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <div style={{ fontFamily: t.fontDisplay, fontSize: 36, color: t.text, lineHeight: 1.0, letterSpacing: -0.6, fontStyle: t.id === "v4" ? "italic" : "normal" }}>
          Partilha o<br/>teu raio-x.
        </div>
        <div style={{ fontSize: 14, color: t.muted, marginTop: 14, maxWidth: 280 }}>
          Manda a um colega comerciante.<br/>Demoram 90 segundos a ver o deles.
        </div>

        <button onClick={e => { e.stopPropagation(); window.open(`https://wa.me/?text=${encodeURIComponent("Acabei de fazer um raio-x digital da minha loja em 90 seg. Toma o teu: " + shareUrl + " — AHI")}`, "_blank"); }}
          style={{
            marginTop: 28, padding: "16px 18px", fontSize: 16, fontFamily: t.fontBody, fontWeight: 600,
            background: t.accent, color: t.dark ? "#14110d" : "#fbf9f4", border: "none",
            borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer", marginBottom: 8,
          }}>
          Partilhar no WhatsApp 👋
        </button>
        <button onClick={e => { e.stopPropagation(); copy(); }}
          style={{
            padding: "14px 18px", fontSize: 15, fontFamily: t.fontBody,
            background: "transparent", color: t.text, border: `1px solid ${t.rule}`,
            borderRadius: t.radius === 0 ? 0 : t.radius + 6, cursor: "pointer",
          }}>
          {copied ? "Copiado ✓" : "Copiar link"}
        </button>
      </div>

      <div style={{ borderTop: `1px solid ${t.rule}`, paddingTop: 14, marginTop: 14 }}>
        <div style={{ fontFamily: t.fontDisplay, fontStyle: "italic", fontSize: 14, color: t.muted, lineHeight: 1.4 }}>
          Já ajudámos 200+ comerciantes do Porto este ano.
        </div>
        <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.muted, letterSpacing: 1.8, textTransform: "uppercase", marginTop: 6 }}>— AHI</div>
      </div>
    </div>
  );
}

Object.assign(window, { Reveal, useCountUp });
