// RaioXApp — state machine for one variant. Showcase — 4 variants on a canvas.

const { useState: usS2, useEffect: usE2 } = React;

function RaioXApp({ variant = "v1", paceMs = 1100, startPhase = "search", startScene = 0 }) {
  const theme = VARIANTS[variant];
  const [phase, setPhase] = usS2(startPhase);
  const [shop, setShop] = usS2(null);

  // resync to external prop changes (Tweaks)
  usE2(() => { setPhase(startPhase); }, [startPhase, variant]);

  function reset() { setShop(null); setPhase("search"); }

  return (
    <div style={{ width: "100%", height: "100%", background: theme.bg, overflow: "hidden", color: theme.text }}>
      {phase === "search" && (
        <Phase1Search theme={theme} onSelect={p => { setShop(p); setPhase("confirm"); }} />
      )}
      {phase === "confirm" && shop && (
        <Phase2Confirm theme={theme} shop={shop} onConfirm={() => setPhase("waiting")} onBack={() => setPhase("search")} />
      )}
      {phase === "waiting" && shop && (
        <Phase3Waiting theme={theme} shop={shop} paceMs={paceMs} onDone={() => setPhase("reveal")} />
      )}
      {phase === "reveal" && (
        <Reveal theme={theme} result={MOCK_RESULT} onRestart={reset} />
      )}
      {phase === "shared" && (
        <Reveal theme={theme} result={MOCK_RESULT} isSharedView onRestart={reset} />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Showcase — design canvas with 4 variants
// ─────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "pace": "fast",
  "startPhase": "search",
  "showSharedFifth": true
}/*EDITMODE-END*/;

function PhoneFrame({ children }) {
  return (
    <IOSDevice width={393} height={812} dark={false}>
      {children}
    </IOSDevice>
  );
}

function VariantHeading({ theme: t, label }) {
  return (
    <div style={{ marginBottom: 18, fontFamily: "-apple-system, system-ui", color: "#2a261f" }}>
      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: "#7a7167", marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: t.fontDisplay, fontSize: 30, lineHeight: 1, letterSpacing: -0.5, color: "#1a1815" }}>
        <i>{t.name}</i>
      </div>
      <div style={{ fontSize: 13, color: "#7a7167", marginTop: 4 }}>{t.tagline}</div>
    </div>
  );
}

// per-variant controls (jump to phase/scene)
function MiniControls({ theme: t, phase, setPhase }) {
  const opts = [["search", "1·Procurar"], ["confirm", "2·Confirmar"], ["waiting", "3·Espera"], ["reveal", "4·Revelação"], ["shared", "5·Partilhada"]];
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 12 }}>
      {opts.map(([k, label]) => (
        <button key={k}
          onClick={() => setPhase(k)}
          style={{
            padding: "4px 8px", fontSize: 11, fontFamily: "'JetBrains Mono', monospace",
            background: phase === k ? t.accent : "transparent",
            color: phase === k ? (t.dark ? "#fbf9f4" : "#fff") : "#5a5448",
            border: `1px solid ${phase === k ? t.accent : "#d8d0bf"}`,
            borderRadius: 0, cursor: "pointer",
            letterSpacing: 0.5,
          }}>
          {label}
        </button>
      ))}
    </div>
  );
}

function VariantCard({ variant, label, tweaks, setPhaseFn, phase }) {
  const theme = VARIANTS[variant];
  // Hack to allow remount when phase changes between non-search states using a key
  const [seed, setSeed] = usS2(0);
  function setPhase(p) {
    setPhaseFn(variant, p);
    setSeed(s => s + 1);
  }
  const paceMs = tweaks.pace === "fast" ? 900 : tweaks.pace === "slow" ? 1600 : 1200;

  // If a phase requires a shop (confirm/waiting), pre-seed with Casa Januário.
  // We do this by passing the right startPhase + ensuring our app preseeds shop in that phase.
  return (
    <div style={{ width: 430, padding: 16, background: "#f5f0e6", border: "1px solid #e3dcce", borderRadius: 12 }}>
      <VariantHeading theme={theme} label={label} />
      <PhoneFrame>
        <RaioXAppWithSeed key={`${variant}-${phase}-${seed}`} variant={variant} paceMs={paceMs} phase={phase} />
      </PhoneFrame>
      <MiniControls theme={theme} phase={phase} setPhase={setPhase} />
    </div>
  );
}

// wrapper that pre-seeds shop when phase needs one
function RaioXAppWithSeed({ variant, paceMs, phase }) {
  const theme = VARIANTS[variant];
  const [internal, setInternal] = usS2({ phase, shop: phase === "search" ? null : MOCK_PREDICTIONS[0] });

  function reset() { setInternal({ phase: "search", shop: null }); }
  function setPhase(p) { setInternal(s => ({ ...s, phase: p })); }

  return (
    <div style={{ width: "100%", height: "100%", background: theme.bg, overflow: "hidden", color: theme.text }}>
      {internal.phase === "search" && (
        <Phase1Search theme={theme} onSelect={p => setInternal({ phase: "confirm", shop: p })} />
      )}
      {internal.phase === "confirm" && internal.shop && (
        <Phase2Confirm theme={theme} shop={internal.shop} onConfirm={() => setPhase("waiting")} onBack={() => setPhase("search")} />
      )}
      {internal.phase === "waiting" && internal.shop && (
        <Phase3Waiting theme={theme} shop={internal.shop} paceMs={paceMs} onDone={() => setPhase("reveal")} />
      )}
      {internal.phase === "reveal" && (
        <Reveal theme={theme} result={MOCK_RESULT} onRestart={reset} />
      )}
      {internal.phase === "shared" && (
        <Reveal theme={theme} result={MOCK_RESULT} isSharedView onRestart={reset} />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Showcase Layout
// ─────────────────────────────────────────────
function Showcase() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [perVariantPhase, setPVP] = usS2({
    v1: tweaks.startPhase,
    v2: tweaks.startPhase,
    v3: tweaks.startPhase,
    v4: tweaks.startPhase,
  });

  usE2(() => {
    setPVP({ v1: tweaks.startPhase, v2: tweaks.startPhase, v3: tweaks.startPhase, v4: tweaks.startPhase });
  }, [tweaks.startPhase]);

  function setPhaseFn(variant, p) {
    setPVP(prev => ({ ...prev, [variant]: p }));
  }

  return (
    <React.Fragment>
      <DesignCanvas title="Raio-X Digital — design pass" subtitle="Casa Januário · 4 direcções · iOS protótipo">
        <DCSection id="phones" title="Fluxo completo, 4 direcções">
          {["v1","v2","v3","v4"].map(v => (
            <DCArtboard key={v} id={v} label={`${v.toUpperCase()} · ${VARIANTS[v].name}`} width={462} height={1010}>
              <VariantCard variant={v} label={`Direcção ${v.toUpperCase()}`} tweaks={tweaks} phase={perVariantPhase[v]} setPhaseFn={setPhaseFn} />
            </DCArtboard>
          ))}
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks · Raio-X">
        <TweakSection label="Demo">
          <TweakRadio label="Ritmo" value={tweaks.pace} onChange={v => setTweak("pace", v)} options={[{ value: "fast", label: "Rápido" }, { value: "normal", label: "Normal" }, { value: "slow", label: "Lento" }]} />
          <TweakSelect label="Saltar para fase" value={tweaks.startPhase} onChange={v => setTweak("startPhase", v)} options={[
            { value: "search", label: "1 · Procurar loja" },
            { value: "confirm", label: "2 · Confirmar loja" },
            { value: "waiting", label: "3 · Espera 90s" },
            { value: "reveal", label: "4 · Revelação (8 cenas)" },
            { value: "shared", label: "5 · Vista partilhada" },
          ]} />
        </TweakSection>
        <TweakSection label="Notas">
          <div style={{ fontSize: 12, color: "#666", lineHeight: 1.5, padding: "0 14px" }}>
            Toca em qualquer telefone para avançar entre cenas na fase 4. Os botões por baixo de cada telefone saltam directamente para a fase.
          </div>
        </TweakSection>
      </TweaksPanel>
    </React.Fragment>
  );
}

Object.assign(window, { RaioXApp, Showcase });
