// Casa Januário mock + helpers
const MOCK_PREDICTIONS = [
  { place_id: "ChIJSTUB_casa_januario", name: "Casa Januário", address: "Rua Cedofeita 348, 4050-174 Porto", category: "grocery_store" },
  { place_id: "ChIJSTUB_casa_januaria", name: "Casa Januária", address: "Rua do Bonfim, Porto", category: "store" },
  { place_id: "ChIJSTUB_chajanuario", name: "Casa de Chá Januário", address: "Rua Sá da Bandeira, Porto", category: "tea_house" },
  { place_id: "ChIJSTUB_pinguim", name: "Pinguim Café", address: "Rua Galeria de Paris, Sé, Porto", category: "cafe" },
  { place_id: "ChIJSTUB_moutinho", name: "Moutinho Ópticas", address: "Rua Cedofeita, Porto", category: "store" },
];

// progress event timeline — mirrors brief mock
const MOCK_PROGRESS = [
  { atSec: 0,  stage: "identifying",        text: "A encontrar a Casa Januário em Cedofeita…" },
  { atSec: 2,  stage: "scanning_google",    text: "87 reviews no Google — boa tracção.",        data: { reviews_count: 87, rating: 4.3 } },
  { atSec: 4,  stage: "scanning_web",       text: "Encontrei-te no Comércio com História.",     data: { source_found: "Comércio com História" } },
  { atSec: 6,  stage: "scanning_site",      text: "Site activo — casajanuario.pt",              data: { site_url: "casajanuario.pt", facebook_followers: 8849 } },
  { atSec: 8,  stage: "scanning_instagram", text: "Instagram: 1 522 seguidores, 449 publicações.", data: { instagram_followers: 1522, instagram_posts: 449, last_post_days_ago: 23 } },
  { atSec: 10, stage: "scanning_web",       text: "Time Out: a Cedofeita é a 3.ª rua mais cool do mundo.", data: { source_found: "Time Out Coolest Streets" } },
  { atSec: 12, stage: "synthesizing",       text: "A juntar tudo numa análise…" },
];

const MOCK_RESULT = {
  shop: { name: "Casa Januário", address: "Rua Cedofeita 348, 4050-174 Porto", place_id: "ChIJSTUB_casa_januario" },
  axes: [
    {
      name: "Visibilidade",
      summary: "Já tens presença em múltiplos canais — site com loja online, Instagram, Facebook, Comércio com História e até a Time Out te citou. A maior oportunidade está em crescer no Instagram: 1 522 seguidores é pouco para uma loja com esta notoriedade.",
      recommendations: [
        { action: "Activa o Instagram com um post por semana centrado num produto icónico ou numa história da loja — a longevidade de 100 anos é conteúdo que se escreve sozinho." },
        { action: "Confirma que o horário no Google Maps está actualizado e bate certo com o do Comércio com História." },
      ],
      evidence_count: 6,
      bigNumber: { value: 6, label: "canais onde apareces" },
    },
    {
      name: "Reputação",
      summary: "Já tens 87 avaliações no Google com 4.3 estrelas e menções editoriais na Time Out e JN. A maior oportunidade está em responder publicamente às reviews — agora não há respostas tuas a 5 reviews recentes, e isso muda a leitura para quem chega.",
      recommendations: [
        { action: "Responde às próximas 10 reviews do Google com uma frase personalizada que mencione o produto descrito pelo cliente." },
        { action: "Pede a 5 clientes habituais por semana que deixem uma review no Google — uma frase chega." },
      ],
      evidence_count: 87,
      bigNumber: { value: 87, label: "reviews", suffix: "4,3 estrelas" },
    },
    {
      name: "Consistência",
      summary: "Já tens uma narrativa coerente — mercearia fina desde 1926, terceira geração — em todos os directórios. A maior oportunidade está em dois detalhes: a imagem de partilha do site está em falta e o número da porta difere entre fontes (348 vs 352).",
      recommendations: [
        { action: "Adiciona uma og:image ao site — quando alguém partilha o link no WhatsApp, aparece uma caixa cinzenta em vez de uma foto da loja." },
        { action: "Confirma e unifica o número da porta (348 ou 352) no Google Maps, no site e no Facebook." },
      ],
      bigNumber: { value: "2 / 3", label: "canais alinhados" },
    },
  ],
  lab_hint: "lab_2",
  generated_at: "2026-05-15T14:30:00Z",
  model_variant: "sonnet",
};

const LAB_MAP = {
  lab_1: { num: 1, title: "FAQ automática da loja" },
  lab_2: { num: 2, title: "Planeador de campanhas" },
  lab_3: { num: 3, title: "Montra em QR Code" },
};

// PT-PT number formatting
const fmtPT = (n) => {
  if (typeof n === "string") return n;
  return new Intl.NumberFormat("pt-PT").format(n);
};

// Map progress data → fact card content
function factFromProgress(p) {
  const d = p.data || {};
  if (d.reviews_count != null) return { value: d.reviews_count, label: "reviews no Google", sub: d.rating ? `${String(d.rating).replace(".", ",")} ★` : null };
  if (d.instagram_followers != null) return { value: d.instagram_followers, label: "seguidores no Instagram", sub: d.instagram_posts ? `${fmtPT(d.instagram_posts)} publicações` : null };
  if (d.facebook_followers != null) return { value: d.facebook_followers, label: "seguidores no Facebook", sub: d.site_url || null };
  if (d.last_post_days_ago != null) return { value: d.last_post_days_ago, label: "dias desde a última publicação" };
  if (d.source_found) return { value: d.source_found, label: "mais um sítio onde apareces", isString: true };
  if (d.site_url) return { value: d.site_url, label: "o teu site", isString: true };
  if (d.hours_today) return { value: d.hours_today, label: "horário hoje", isString: true };
  return null;
}

const STAGE_PROGRESS = {
  identifying: 0.10,
  scanning_google: 0.30,
  scanning_instagram: 0.50,
  scanning_site: 0.65,
  scanning_web: 0.80,
  synthesizing: 0.95,
  done: 1.0,
};

Object.assign(window, { MOCK_PREDICTIONS, MOCK_PROGRESS, MOCK_RESULT, LAB_MAP, fmtPT, factFromProgress, STAGE_PROGRESS });
